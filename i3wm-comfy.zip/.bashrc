#
# ~/.bashrc
#

# If not running interactively, don't do anything
[[ $- != *i* ]] && return

alias ls='ls --color=auto'
alias grep='grep --color=auto'
PS1='[\u@\h \W]\$ '

# fasfetch
if [ "$TERM" = "alacritty" ] && command -v fastfetch >/dev/null; then
  fastfetch
  echo
fi

# Prompt
PS1='\[\e[34m\]\W\[\e[0m\] \[\e[32m\]❯\[\e[0m\] '

# prompt
PS1='\[\e[34m\]\W\[\e[0m\] \[\e[32m\]❯\[\e[0m\] '

# prompt
PS1='\[\e[32m\]\u\[\e[0m\]@\[\e[36m\]\h\[\e[0m\] \[\e[34m\]\w\[\e[0m\] \$ '

# border prompt
PS1='\[\e[36m\]╭─\[\e[0m\][\[\e[32m\]\u@\h\[\e[0m\]]─[\[\e[34m\]\w\[\e[0m\]]\n\[\e[36m\]╰─\[\e[32m\]❯\[\e[0m\] '

# fastfetch
alias clear='command clear && fastfetch && echo'

export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"  # This loads nvm
[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"  # This loads nvm bash_completion
